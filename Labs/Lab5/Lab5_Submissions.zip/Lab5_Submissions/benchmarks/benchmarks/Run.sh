#!/bin/bash
BENCH=$1
RESULTS=${BENCH}_results.txt
CONFIGS=${BENCH}/gpgpusim.config
OUTFILE=${BENCH}/out.txt

if [ ${BENCH} == BFS ]
then
    PARAM="./graph65536.txt"
elif [ ${BENCH} == JPEG ]
then
    PARAM="--decode --file=./cameraman.bmp"
elif [ ${BENCH} == LPS ]
then
    PARAM='--nx=128 --ny=128 --nz=128'
elif [ ${BENCH} == SCP ]
then
    PARAM='--vector_n=4096 --element_n=4096'
elif [ ${BENCH} == SLA ]
then
    PARAM='--n=300000'
elif [ ${BENCH} == TRA ]
then
    PARAM='--size_x=1024 --size_y=1024'
else
    echo "Invalid Param"
    exit 0
fi

echo "[=>] Benchmark Tester"
rm -rf ${RESULTS}

echo "[=>] Disable Power Simulation"
sed -i "/-power_simulation_enabled/s/ .*/ 0/" ${CONFIGS}

echo "[=>] Bandwidth Test"
echo "${BENCH} Bandwidth Change :=" >> ${RESULTS}
for bw in 1 2 4 8 16
do
    sed -i "/-gpgpu_dram_buswidth/s/ .*/ $bw/" ${CONFIGS}
    echo "[>] Bandwidth: $bw"
    (cd ./${BENCH} && ./gpgpu_ptx_sim__${BENCH} ${PARAM} > out.txt)
    echo "Bandwidth: $bw" >> ${RESULTS}
    ipc=`grep -w gpu_tot_ipc ${OUTFILE}`
    echo -e $ipc >> ${RESULTS}
    l1cache=`grep -w L1D_total_cache_miss_rate ${OUTFILE}`
    echo -e $l1cache >> ${RESULTS}
    grep -w L2_total_cache_miss_rate ${OUTFILE} >> ${RESULTS}
    grep -w bwutil ${OUTFILE} >> ${RESULTS}
done

sed -i "/-gpgpu_dram_buswidth/s/ .*/ 4/" ${CONFIGS}

echo "[=>] L1 Cache Test"
echo "${BENCH} L1 Cache Change :=" >> ${RESULTS}
for l1c in 2 4 8 16 32
do
    sed -i "/-gpgpu_cache:dl1/s/  .*/  N:32:128:$l1c,L:L:m:N:H,S:64:8,8/" ${CONFIGS}
    echo "[>] L1 Cache: $l1c"
    (cd ./${BENCH} && ./gpgpu_ptx_sim__${BENCH} ${PARAM} > out.txt)
    echo "L1 Cache: $l1c" >> ${RESULTS}
    ipc=`grep -w gpu_tot_ipc ${OUTFILE}`
    echo -e $ipc >> ${RESULTS}
    l1cache=`grep -w L1D_total_cache_miss_rate ${OUTFILE}`
    echo -e $l1cache >> ${RESULTS}
    grep -w L2_total_cache_miss_rate ${OUTFILE} >> ${RESULTS}
    grep -w bwutil ${OUTFILE} >> ${RESULTS}
done

sed -i "/-gpgpu_cache:dl1/s/  .*/  N:32:128:4,L:L:m:N:H,S:64:8,8/" ${CONFIGS}

echo "[=>] L2 Cache Test"
echo "${BENCH} L2 Cache Change :=" >> ${RESULTS}
for l2c in 4 8 16 32 64
do
    sed -i "/-\<gpgpu_cache:dl2\>/s/ .*/ S:64:128:$l2c,L:B:m:L:L,A:256:4,4:0,32/" ${CONFIGS}
    echo "[>] L2 Cache: $l2c"
    (cd ./${BENCH} && ./gpgpu_ptx_sim__${BENCH} ${PARAM} > out.txt)
    echo "L2 Cache: $l2c" >> ${RESULTS}
    ipc=`grep -w gpu_tot_ipc ${OUTFILE}`
    echo -e $ipc >> ${RESULTS}
    l1cache=`grep -w L1D_total_cache_miss_rate ${OUTFILE}`
    echo -e $l1cache >> ${RESULTS}
    grep -w L2_total_cache_miss_rate ${OUTFILE} >> ${RESULTS}
    grep -w bwutil ${OUTFILE} >> ${RESULTS}
done

sed -i "/-\<gpgpu_cache:dl2\>/s/ .*/ S:64:128:8,L:B:m:L:L,A:256:4,4:0,32/" ${CONFIGS}

echo "[=>] Warp schedulers Test"
echo "${BENCH} Warp schedulers Change :=" >> ${RESULTS}
for sch in 'gto' 'lrr' 'two_level_active:6:0:1'
do
    sed -i "/-gpgpu_scheduler/s/ .*/ $sch/" ${CONFIGS}
    echo "[>] Warp schedulers: $sch"
    (cd ./${BENCH} && ./gpgpu_ptx_sim__${BENCH} ${PARAM} > out.txt)
    echo "Warp schedulers: $sch" >> ${RESULTS}
    ipc=`grep -w gpu_tot_ipc ${OUTFILE}`
    echo -e $ipc >> ${RESULTS}
    l1cache=`grep -w L1D_total_cache_miss_rate ${OUTFILE}`
    echo -e $l1cache >> ${RESULTS}
    grep -w L2_total_cache_miss_rate ${OUTFILE} >> ${RESULTS}
    grep -w bwutil ${OUTFILE} >> ${RESULTS}
done

sed -i "/-gpgpu_scheduler/s/ .*/ gto/" ${CONFIGS}

echo "[=>] Enable Power Simulation"
sed -i "/-power_simulation_enabled/s/ .*/ 1/" ${CONFIGS}
echo "[=>] All Done"