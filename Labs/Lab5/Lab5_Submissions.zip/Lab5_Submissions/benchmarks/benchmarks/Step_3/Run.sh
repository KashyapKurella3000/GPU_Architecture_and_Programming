#!/bin/bash
BENCH=$1
RESULTS=${BENCH}_results.txt
CONFIGS=${BENCH}/gpgpusim.config
OUTFILE=${BENCH}/out.txt

if [ ${BENCH} == BFS ]
then
    PARAM="./graph65536.txt"
elif [ ${BENCH} == JPEG ]
then
    PARAM="--decode --file=./cameraman.bmp"
elif [ ${BENCH} == LPS ]
then
    PARAM='--nx=128 --ny=128 --nz=128'
elif [ ${BENCH} == SCP ]
then
    PARAM='--vector_n=4096 --element_n=4096'
elif [ ${BENCH} == SLA ]
then
    PARAM='--n=300000'
elif [ ${BENCH} == TRA ]
then
    PARAM='--size_x=1024 --size_y=1024'
else
    echo "Invalid Param"
    exit 0
fi

echo "[=>] Benchmark Tester"
rm -rf ${RESULTS}

echo "[=>] Disable Power Simulation"
sed -i "/-power_simulation_enabled/s/ .*/ 0/" ${CONFIGS}

echo "[=>] SWL Scheduler"
echo "${BENCH} Warp Limit Change :=" >> ${RESULTS}
for sch in 1 2 4 8 16 24 32 48
do
    sed -i "/-\<gpgpu_scheduler\>/s/ .*/ warp_limiting:2:$sch/" ${CONFIGS}
    echo "[>] Warp Limit: $sch"
    (cd ./${BENCH} && ./gpgpu_ptx_sim__${BENCH} ${PARAM} > out.txt)
    echo "Warp Limit: $sch" >> ${RESULTS}
    ipc=`grep -w gpu_tot_ipc ${OUTFILE}`
    echo -e $ipc >> ${RESULTS}
    l1cache=`grep -w L1D_total_cache_miss_rate ${OUTFILE}`
    echo -e $l1cache >> ${RESULTS}
    grep -w L2_total_cache_miss_rate ${OUTFILE} >> ${RESULTS}
    grep -w bwutil ${OUTFILE} >> ${RESULTS}
done

sed -i "/-\<gpgpu_scheduler\>/s/ .*/ gto/" ${CONFIGS}

echo "[=>] Enable Power Simulation"
sed -i "/-power_simulation_enabled/s/ .*/ 1/" ${CONFIGS}
echo "[=>] All Done"